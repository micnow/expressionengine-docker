$(function(){

	// ===============
	// cycle
	// ===============

		$('.cycle-slideshow').cycle();

}); // close (document).ready