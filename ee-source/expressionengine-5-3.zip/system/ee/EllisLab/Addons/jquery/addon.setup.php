<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Jquery',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\Jquery',
	'settings_exist' => FALSE,
	'docs_url'       => DOC_URL.'add-ons/jquery/index.html',
	'built_in'       => FALSE
);
