<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'IP to Nation',
	'description' => '',
	'version'     => '3.0.0',
	'namespace'   => 'EllisLab\Addons\IpToNation',
	'settings_exist' => TRUE,
);
