<div class="box">
	<div class="updater-working">
		<div class="updater-load"></div>
		<h1><?=$title?></h1>
		<ul class="updater-steps">
			<li class="updater-step-work"><?=$subtitle?><span>...</span></li>
		</ul>
	</div>
</div>
