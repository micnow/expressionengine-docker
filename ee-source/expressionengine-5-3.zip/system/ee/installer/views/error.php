<div class="box issue">
	<h1><?=$title?><span class="icon-issue"></span></h1>
	<div class="updater-msg">
		<p><?=lang('error_occurred')?></p>
		<div class="alert-notice">
			<p><?=$error?></p>
		</div>
		<p class="msg-choices"><a href="#" onclick="location.reload()"><?=lang('retry')?></a></p>
	</div>
</div>
